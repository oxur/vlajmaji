import hashlib,json,pathlib,sqlite3,subprocess
import composition as c
r=c.ROOT;s=pathlib.Path('/Users/oubiwann/lab/oxur/vlajmaji/.worktrees/project01-arc01/vlajmaji');a=pathlib.Path('/Users/oubiwann/lab/oxur/vlajmaji/.worktrees/planning/project01-multi-source-dictionary/arc01-dictionary-foundation')
checks=[];runs=[]
def ck(label,value):
 assert value,label
 checks.append(label)
def run(label,args,input=None,rc=0):
 p=subprocess.run([str(x) for x in args],input=input,text=True,capture_output=True);(r/(label+'.stdout')).write_text(p.stdout);(r/(label+'.stderr')).write_text(p.stderr);runs.append(dict(label=label,args=[str(x) for x in args],stdin=input,rc=p.returncode));ck(label+' rc',p.returncode==rc);return p
base=r/'baseline';db=base/'cli-store';cli=c.CLI;caller=c.CALLER
for label,text,code in [('malformed-json','{','request_json'),('unknown-request-field','{"operation":"exact","spelling":"farvi","invented":true}','request_json'),('malformed-cursor','{"operation":"exact","spelling":"farvi","options":{"cursor":"zz"}}','malformed_cursor'),('wrong-local-role','{"operation":"resolve","target":{"Local":{"Assertion":"entry-a-si-e"}}}','invalid_reference')]:
 p=run('transport-'+label,[cli,'dictionary-query',db],input=text,rc=1);ck(label+' stdout empty',p.stdout=='');v=json.loads(p.stderr);ck(label+' envelope',set(v)=={'error'} and v['error']['code']==code)
p=run('legacy-invalid-query',[cli,'search',base/'legacy-store','--query','{'],rc=1);ck('legacy plain diagnostic',p.stdout=='' and p.stderr.startswith('decode query JSON:'))
p=run('nested-registry-error',[caller,'query',base/'rust-store','{"operation":"exact","spelling":"farvi","options":{"sources":["unknown-source"]}}'],rc=2);v=json.loads(p.stdout);ck('typed registry nested Error::source',v['debug'].startswith('Registry(') and v['nested_source'] is not None and v['error']['code']=='unknown_source')
# Independently derived ordered raw seven candidate IDs, not just their cardinality.
for name in ['baseline','disabled-a','removed-a','readded-a','owned-r2','renamed-paths']:
 d=json.loads((r/name/'input.json').read_bytes());es={e['id']:e for e in d['metadata']['entries']}
 want=sorted([a for a in d['metadata']['assertions'] if a['eligibility']=='Lexical' and es[a['entry']]['spelling']=={'Value':'farvi'}],key=lambda a:(es[a['entry']]['source'].encode(),b'farvi',c.oid(a['occurrence']).encode()))
 command=next(v for v in json.loads((r/'commands.json').read_text()) if v['label']==name+'-public-create');proof=json.loads(pathlib.Path(command['stdout']).read_text());ck(name+' exact seven candidate identities',proof['candidates']==[a['id'] for a in want] and len(want)==7)
 # Inspect immutable relational bytes independently in read-only mode; no schema mutation.
 connection=sqlite3.connect('file:'+str(r/name/'rust-store'/'dictionary.sqlite3')+'?mode=ro',uri=True)
 canonical,legacy=connection.execute('SELECT json,legacy_archive FROM canonical_document WHERE id=1').fetchone();ck(name+' exact persisted canonical',canonical==(r/name/'canonical.json').read_bytes());ck(name+' exact persisted legacy',legacy==(bytes(d['legacy_archive']) if d['legacy_archive'] is not None else None))
 captures=connection.execute('SELECT namespace,sha256,bytes FROM raw_captures').fetchall();ck(name+' raw capture bytes',sorted(captures)==sorted((x['identity']['namespace'],x['identity']['sha256'],bytes(x['bytes'])) for x in d['captures']))
 native=connection.execute('SELECT count(*) FROM native_fields').fetchone()[0];ck(name+' native field accounting',native==sum(len(o['fields']) for cap in d['captures'] for o in cap['occurrences']))
 tables=connection.execute("SELECT count(*) FROM sqlite_schema WHERE type='table' AND name NOT LIKE 'sqlite_%'").fetchone()[0];ck(name+' all47table schema',tables==47);connection.close()
# Accepted proof guards: immutable schema/model/registry; S04 additions exact diff attributed.
refs={'registry':'11ec7017a375fa62ba101cb51d85c36034621b81','model':'37c35185cbf1262658504278af1590b50b0b098d','store':'01a9ceb3bd6925d5cae583d38e2683046a3c1dea','query':'efef9c4e661e0b90f79abf4eab41148e095a8c36'}
groups={'registry':['crates/lexicon/src/registry.rs','crates/lexicon/src/attribution.rs'],'model':['crates/lexicon/src/dictionary.rs','crates/lexicon/examples/support/dictionary_fixture.rs'],'store':['crates/store/src/dictionary_schema.rs'],'query':['crates/search/src/dictionary.rs','crate/cli/src/main.rs']};guards=[]
for key,paths in groups.items():
 for path in paths:
  raw=(s/path).read_bytes();prior=subprocess.check_output(['git','show',f'{refs[key]}:{path}'],cwd=s);ck(path+' accepted pin guard',raw==prior);guards.append(dict(path=path,ref=refs[key],sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw)))
path='crates/store/src/dictionary.rs';current=(s/path).read_text();prior=subprocess.check_output(['git','show',refs['store']+':'+path],cwd=s,text=True)
start=current.index('\n    /// Return stable assertion entity IDs');end=current.index('\n}\n\nfn invalid',start)
ck('S03store lifecycle unchanged excluding accepted S04 SQL addition',current[:start]+current[end:]==prior)
(r/'store-s04-addition.diff').write_text(subprocess.check_output(['git','diff',refs['store']+'..HEAD','--',path],cwd=s,text=True))
ck('clean frozen source',subprocess.check_output(['git','status','--porcelain'],cwd=s,text=True)=='')
ck('exact frozen source',subprocess.check_output(['git','rev-parse','HEAD'],cwd=s,text=True).strip()==refs['query'])
(r/'source-guards.json').write_text(json.dumps(guards,indent=2))
(r/'final-controls-results.json').write_text(json.dumps(dict(status='PASS',checks=checks,commands=runs),indent=2))
print(json.dumps(dict(status='PASS',checks=len(checks),commands=len(runs),source=refs['query'])))
