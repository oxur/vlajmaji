use std::{env,fs,error::Error,path::Path};
use vlajmaji_lexicon::{Dictionary,SourceRegistry,Lexicon,AliasScope};
use vlajmaji_store::DictionaryStore;
use vlajmaji_search::{DictionarySearchEngine,DictionaryRequest,DictionaryQueryError};
#[path = "/Users/oubiwann/lab/oxur/vlajmaji/.worktrees/project01-arc01/vlajmaji/crates/lexicon/examples/support/dictionary_fixture.rs"]
mod fixture;
type AnyError=Box<dyn Error+Send+Sync>;
fn failure(e:DictionaryQueryError)->! {
 let nested=e.source().map(ToString::to_string);
 println!("{}",serde_json::json!({"error":e.report(),"debug":format!("{e:?}"),"nested_source":nested}));
 std::process::exit(2)
}
fn run()->Result<(),AnyError>{
 let args:Vec<_>=env::args().collect();
 match args.get(1).map(String::as_str) {
 Some("fixture")=> { fs::write(&args[2],fixture::complete_fixture().map_err(|e|std::io::Error::other(e.to_string()))?.to_json_bytes()?)?; }
 Some("create")=> {
  let bytes=fs::read(&args[2])?;let dictionary=Dictionary::from_json_bytes(&bytes)?;
  let document=dictionary.document();let canonical=dictionary.to_json_bytes()?;
  assert_eq!(Dictionary::from_json_bytes(&canonical)?.document(),document);
  let registry=dictionary.registry();
  assert_eq!(SourceRegistry::from_json_bytes(&registry.to_json_bytes()?)?.document(),registry.document());
  assert_eq!(registry.resolve_source("source-a",AliasScope::ActiveOnly)?.id.as_str(),"source-a");
  for c in dictionary.captures(){
   assert_eq!(dictionary.capture(&c.identity),Some(c));
   for o in &c.occurrences {let rf=vlajmaji_lexicon::OccurrenceRef{capture:c.identity.clone(),locator:o.locator.clone()}; assert_eq!(dictionary.occurrence(&rf),Some(o));}
  }
  let store=DictionaryStore::create(&args[3],&dictionary)?;
  assert_eq!(store.canonical_bytes(),canonical);let candidates=store.exact_assertion_ids("farvi")?;
  drop(store);
  let reopened=DictionaryStore::open(&args[3])?;
  assert_eq!(reopened.canonical_bytes(),canonical); assert_eq!(reopened.dictionary().document(),document);
  assert_eq!(reopened.exact_assertion_ids("farvi")?,candidates);
  fs::write(Path::new(&args[4]).join("canonical.json"),&canonical)?;
  let mut legacy_count=None;
  if let Some(raw)=&document.legacy_archive {
   let legacy=Lexicon::from_archive_bytes(raw)?; assert_eq!(legacy.to_archive_bytes()?,*raw);
   for snap in legacy.snapshots(){ let capture=dictionary.capture(&vlajmaji_lexicon::CaptureRef::from(snap)).ok_or("legacy capture missing")?;assert_eq!(legacy.source_bytes(snap),Some(capture.bytes.as_slice()));}
   let mut rd=registry.document(); rd.snapshots.retain(|x|legacy.snapshots().contains(&&x.snapshot));
   let subset=SourceRegistry::from_document(rd)?;let views=subset.attributed_records(&legacy)?;
   legacy_count=Some((legacy.snapshots().len(),views.len()));
   fs::write(Path::new(&args[4]).join("legacy.archive"),raw)?;
  }
  drop(reopened);
  let engine=DictionarySearchEngine::open(&args[3])?;let q=engine.exact("farvi",Default::default())?;
  println!("{}",serde_json::json!({"counts":engine.dictionary_counts(),"state_sha256":engine.state_sha256(),"candidates":candidates,"legacy_counts":legacy_count,"farvi_total":q.totals.occurrences,"canonical_bytes":canonical.len()}));
 }
 Some("query")=>{
  let request:DictionaryRequest=serde_json::from_str(&args[3])?;
  let engine=DictionarySearchEngine::open(&args[2]).unwrap_or_else(|e|failure(e));
  let value=match request{
   DictionaryRequest::Exact{spelling,options}=>serde_json::to_value(engine.exact(&spelling,options).unwrap_or_else(|e|failure(e)))?,
   DictionaryRequest::Resolve{target}=>serde_json::to_value(engine.resolve(&target).unwrap_or_else(|e|failure(e)))?
  };println!("{value}");
 }
 _=>return Err("usage: fixture OUT | create INPUT STORE OUTDIR | query STORE REQUEST".into())
 };Ok(())
}
fn main(){if let Err(e)=run(){eprintln!("composition caller: {e}");std::process::exit(1)}}
