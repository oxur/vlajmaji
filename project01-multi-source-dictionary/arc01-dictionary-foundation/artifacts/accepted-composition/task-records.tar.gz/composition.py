"""Independent all-four assembly: fixture-only identity/selection references,
plus inspected preimplementation nested-value oracle (attributed, unchanged).
No imports from product implementation, no child observed response used as expected.
"""
import collections, copy, hashlib, json, pathlib, subprocess, sys
import retained_input_reference as transitions
import retained_response_oracle as nested
ROOT=pathlib.Path(__file__).parent
TARGET=pathlib.Path('/Users/oubiwann/lab/oxur/vlajmaji/.worktrees/project01-arc01/target/debug')
CALLER=TARGET/'dictionary-composition-a01-review-ybarer';CLI=TARGET/'vlajmaji'
observations=[];checks=[]
def check(label,actual,expected):
 if actual!=expected:raise AssertionError(f'{label}: actual={actual!r}; expected={expected!r}')
 checks.append(label)
def run(label,args,input=None,rc=0):
 p=subprocess.run([str(x) for x in args],input=input,text=True,capture_output=True)
 index=len(observations);base=ROOT/f'{index:03d}-{label}'
 base.with_suffix('.stdout').write_text(p.stdout);base.with_suffix('.stderr').write_text(p.stderr)
 observations.append(dict(label=label,args=[str(x) for x in args],stdin=input,rc=p.returncode,stdout=str(base.with_suffix('.stdout')),stderr=str(base.with_suffix('.stderr'))))
 (ROOT/'commands.json').write_text(json.dumps(observations,indent=2,ensure_ascii=False))
 check(label+' returncode',p.returncode,rc)
 return p

def oid(o):
 c=o.get('capture',o.get('snapshot'))
 fields=(c['namespace'],c['sha256'],o['locator'])
 return b''.join(len(v.encode('utf-8')).to_bytes(8,'big')+v.encode('utf-8') for v in fields).hex()

def expected_rows(d,word,sources=None):
 m=d['metadata'];entries={e['id']:e for e in m['entries']}
 live=set()
 for release in m['releases']:
  if release['selected'] and release['availability']=='Available':live.update(release['assertions'])
 heads={head['source']:next(r for r in m['owned_revisions'] if r['id']==head['revision'])['assertions'] for head in m['owned_heads']}
 owned={s['id'] for s in d['registry']['sources'] if s['origin']=='OwnedDraft'}
 rows=[]
 for a in m['assertions']:
  e=entries[a['entry']];source=e['source']
  if a['id'] not in live or a['eligibility']!='Lexical' or e['spelling']!={'Value':word}:continue
  if sources is not None and source not in sources:continue
  if source in owned and a['id'] not in heads.get(source,[]):continue
  rows.append((source,word,oid(a['occurrence']),a))
 return sorted(rows,key=lambda x:tuple(part.encode() for part in x[:3]))

def exact_expected(d,word,canonical,sources=None):
 rows=expected_rows(d,word,sources)
 av=nested.availability(d);selected=sorted(sources if sources is not None else [a['source']['id'] for a in av if a['selectable']])
 hits=[nested.hit(d,row[3]) for row in rows]
 counts=collections.Counter(row[0] for row in rows)
 registry={s['id']:s for s in d['registry']['sources']}
 group=[]
 for source in sorted(counts):
  hs=[h for h in hits if h['entry']['source']==source]
  group.append(dict(source=registry[source],full_count=len(hs),returned_count=len(hs),partial=False,hits=hs))
 entries={e['id']:e for e in d['metadata']['entries']}
 candidates=sum(a['eligibility']=='Lexical' and entries[a['entry']]['spelling']=={'Value':word} for a in d['metadata']['assertions'])
 return dict(version=1,policy='exact-entry-v1',store_schema_version=1,catalogue_revision=d['metadata']['catalogue_revision'],state_sha256=hashlib.sha256(canonical).hexdigest(),spelling=word,resolved_sources=selected,native_candidate_occurrences=candidates,totals=dict(occurrences=len(rows),distinct_spellings=int(bool(rows)),source_groups=len(counts)),source_totals=[dict(source=registry[s],occurrences=n,distinct_spellings=1) for s,n in sorted(counts.items())],availability=av,groups=group,next_cursor=None,code_notices=d['metadata']['code_notices'])

def request(kind,store,req,stdin=False,error=None):
 text=json.dumps(req,ensure_ascii=False,separators=(',',':'))
 label=f'{kind}-{store.parent.name}-{len(observations):03d}'
 if kind=='rust':args=[CALLER,'query',store,text];data=None
 else:args=[CLI,'dictionary-query',store]+([] if stdin else ['--request',text]);data=text if stdin else None
 p=run(label,args,data,rc=2 if error and kind=='rust' else 1 if error else 0)
 if error:
  if kind=='cli':check(label+' empty stdout',p.stdout,'');value=json.loads(p.stderr)
  else:value=json.loads(p.stdout)
  check(label+' typed error',value['error']['code'],error)
  return value
 check(label+' empty stderr',p.stderr,'')
 return json.loads(p.stdout)

def flat(response):return [h for g in response['groups'] for h in g['hits']]

def compare_full(label,actual,expected):
 differences=nested.diffs(actual,expected)
 check(label+' complete nested equality',differences,[])

def pages(kind,store,word,expected,size,first_cursor=None):
 rows=[];cursor=first_cursor;count=0
 while True:
  options={'page_size':size}
  if cursor is not None:options['cursor']=cursor
  page=request(kind,store,dict(operation='exact',spelling=word,options=options),stdin=kind=='cli' and count%2==0)
  for field in ['version','policy','store_schema_version','catalogue_revision','state_sha256','spelling','resolved_sources','native_candidate_occurrences','totals','source_totals','availability','code_notices']:
   check(f'{kind} page{size} {count} {field}',page[field],expected[field])
  for g in page['groups']:
   check(f'{kind} group returned',g['returned_count'],len(g['hits']))
   full=next(g0['full_count'] for g0 in expected['groups'] if g0['source']['id']==g['source']['id'])
   check(f'{kind} group full',g['full_count'],full);check(f'{kind} partial',g['partial'],len(g['hits'])<full)
  rows+=flat(page);count+=1;cursor=page['next_cursor']
  if cursor is None:break
  if count>30:raise AssertionError('cursor loop')
 compare_full(f'{kind} all ordered pages size{size}',rows,flat(expected))
 return count

def main():
 raw=(ROOT/'fixture.json').read_bytes();check('fixture SHA',hashlib.sha256(raw).hexdigest(),'c8f4cf31fcf571a7de887db524aa6c9bfe5e73e4bb2f480fb6bb49e25845ce55');check('fixture byte length',len(raw),132946)
 baseline=json.loads(raw);m=baseline['metadata'];reg=baseline['registry'];entries={e['id']:e for e in m['entries']}
 # Independently enumerate assembled source/occurrence population and literal witness tuples.
 check('source roles',[(s['id'],s['origin']) for s in reg['sources']],[('source-a','Upstream'),('source-b','Upstream'),('source-o','OwnedDraft'),('source-m','Upstream')])
 check('population',[len(baseline['captures']),sum(len(c['occurrences']) for c in baseline['captures']),len(m['entries']),len(m['assertions'])],[9,20,14,20])
 check('assertions per source',dict(collections.Counter(entries[a['entry']]['source'] for a in m['assertions'])),{'source-a':17,'source-b':1,'source-o':2})
 expected=expected_rows(baseline,'farvi')
 check('literal expected six tuples',[(r[0],r[3]['occurrence']['capture']['namespace'],r[3]['occurrence']['locator']) for r in expected],[('source-a','captured:a:d1','/0'),('source-a','captured:a:d1','/1'),('source-a','captured:a:d1','/2'),('source-a','captured:a:d2','/0'),('source-b','captured:b:d1','/0'),('source-o','owned:o:r1','/0')])
 check('three repeat five-place observations',sum('$x_5$' in (a['definition'].get('Value',{}).get('text','') if isinstance(a['definition'],dict) else '') for a in m['assertions']),3)
 check('four-place witness',sum('$x_{4}$.' in (a['definition'].get('Value',{}).get('text','') if isinstance(a['definition'],dict) else '') for a in m['assertions']),1)
 check('no inferred farvi frame',[f for f in m['frames'] if entries[next(a['entry'] for a in m['assertions'] if a['id']==f['assertion'])]['spelling']=={'Value':'farvi'}],[])
 states={'baseline':baseline,**transitions.transition_sequence(baseline)}
 results={};reference={};original_cursor=None
 for name,d in states.items():
  state=ROOT/name;state.mkdir();path=state/'input.json'
  data=raw if name=='baseline' else json.dumps(d,ensure_ascii=False,separators=(',',':')).encode()
  path.write_bytes(data);store=state/'rust-store'
  proof=json.loads(run(name+'-public-create',[CALLER,'create',path,store,state]).stdout)
  canonical=(state/'canonical.json').read_bytes();check(name+' own canonical serialization',canonical,data)
  check(name+' canonical hash',proof['state_sha256'],hashlib.sha256(data).hexdigest())
  exp=exact_expected(d,'farvi',canonical);reference[name]=dict(ordered_tuples=[r[:3] for r in expected_rows(d,'farvi')],farvi=exp)
  check(name+' source-only references agree',transitions.scan(d,'farvi')['total_occurrences'],exp['totals']['occurrences'])
  check(name+' expected transition count',exp['totals']['occurrences'],{'baseline':6,'disabled-a':2,'removed-a':2,'readded-a':6,'owned-r2':6,'renamed-paths':6}[name])
  # Independent actual CLI create also traverses full build path, not just opens caller's DB.
  cli_store=state/'cli-store';build=json.loads(run(name+'-cli-create',[CLI,'dictionary-build',path,cli_store]).stdout)
  check(name+' CLI build hash',build['state_sha256'],proof['state_sha256'])
  check(name+' CLI build counts',[build[k] for k in ['captures','occurrences','entries','assertions']],proof['counts'])
  for kind,db in [('rust',store),('cli',cli_store)]:
   response=request(kind,db,dict(operation='exact',spelling='farvi'))
   compare_full(name+' '+kind+' full farvi',response,exp)
   for size in ([1,2,3,4,5,100] if name=='baseline' else [1,4]):pages(kind,db,'farvi',exp,size)
   zero=request(kind,db,dict(operation='exact',spelling='farvi',options={'page_size':0}))
   want=copy.deepcopy(exp);want['groups']=[];compare_full(name+' '+kind+' zero',zero,want)
   if name=='baseline':
    first=request(kind,db,dict(operation='exact',spelling='farvi',options={'page_size':1}))
    if kind=='rust':original_cursor=first['next_cursor']
    else:check('cross public surfaces cursor equality',first['next_cursor'],original_cursor)
   else:request(kind,db,dict(operation='exact',spelling='farvi',options={'page_size':1,'cursor':original_cursor}),error='stale_cursor')
   # Full historical reference survives disable/removal/owned edit and display path rename.
   historic=next(a for a in m['assertions'] if a['occurrence']['capture']['namespace']=='owned:o:r1')
   refs=[{'Local':{'Entry':'entry-a-si-e'}},{'Local':{'Assertion':historic['id']}},{'Local':{'Form':'form-assigned'}},{'Local':{'EditorialSense':'editorial-farvi'}},next(r['target'] for r in m['relations'] if r['id']=='relation-missing-catalogue'),{'Catalog':{'source':'source-a','release':'release-a','native_entry_id':'333','native_assertion_id':'69002','occurrence':None}}]
   for target in refs:
    actual=request(kind,db,dict(operation='resolve',target=target));want=nested.resolved(d,target);want['state_sha256']=hashlib.sha256(canonical).hexdigest()
    compare_full(name+' '+kind+' stable reference',actual,want)
    if target.get('Catalog',{}).get('native_assertion_id')=='69002':
     check(name+' native confidence',[len(actual['confirmed']),len(actual['unverified'])],[3,13])
     check(name+' no four-place confirmed',any(x['occurrence_attribution'] and x['occurrence_attribution']['native_assertion_id']=='333' for x in actual['confirmed']),False)
   if name in ['disabled-a','removed-a']:request(kind,db,dict(operation='exact',spelling='farvi',options={'sources':['a']}),error='unavailable_source')
  results[name]={'counts':proof['counts'],'farvi':exp['totals'],'state_sha256':proof['state_sha256']}
  if name=='baseline':
   for word in ["si'e",'sie',"Si'e",'si’e',".si'e",'sy','bai','le jaica','cpana','cpan','snime','snim','never-a-word']:
    expword=exact_expected(d,word,canonical)
    for kind,db in [('rust',store),('cli',cli_store)]:compare_full(kind+' exact variant '+word,request(kind,db,dict(operation='exact',spelling=word),stdin=True),expword)
   for kind,db in [('rust',store),('cli',cli_store)]:
    for selectors in [['source-a'],['a','source-a','archive-a'],['source-b'],['o']]:
     selected={'source-a'} if selectors[0] in ['source-a','a'] else {'source-b'} if selectors[0]=='source-b' else {'source-o'}
     compare_full(kind+' explicit source',request(kind,db,dict(operation='exact',spelling='farvi',options={'sources':selectors})),exact_expected(d,'farvi',canonical,selected))
    compare_full(kind+' available zero',request(kind,db,dict(operation='exact',spelling="si'e",options={'sources':['b']})),exact_expected(d,"si'e",canonical,{'source-b'}))
    for selector,code in [('m','unavailable_source'),('not-a-source','unknown_source'),('legacy-a','unknown_source')]:request(kind,db,dict(operation='exact',spelling='farvi',options={'sources':[selector]}),error=code)
    compare_full(kind+' retired explicit',request(kind,db,dict(operation='exact',spelling='farvi',options={'sources':['legacy-a'],'alias_scope':'IncludeRetired'})),exact_expected(d,'farvi',canonical,{'source-a'}))
   # Explicit wrong native assertion constraints must exclude rather than guess from sense/text.
   wrong={'Catalog':{'source':'source-a','release':'release-a','native_entry_id':'333','native_assertion_id':'333','occurrence':None}}
   for kind,db in [('rust',store),('cli',cli_store)]:
    response=request(kind,db,dict(operation='resolve',target=wrong));check(kind+' known native alternate',[len(response['confirmed']),len(response['unverified'])],[1,13])
   # Fresh built-in CLI legacy commands against exact retained archive bytes.
   legacy=state/'legacy-store';legacybytes=(state/'legacy.archive').read_bytes()
   check('legacy rows/snapshots public caller',proof['legacy_counts'],[8,19])
   legacybuild=json.loads(run('legacy-cli-build',[CLI,'build',state/'legacy.archive',legacy]).stdout)
   check('legacy build',[legacybuild['records'],legacybuild['snapshots']],[19,8])
   info=json.loads(run('legacy-cli-info',[CLI,'info',legacy]).stdout);check('legacy info counts',[info['records'],info['snapshots']],[19,8])
   search=run('legacy-cli-search',[CLI,'search',legacy,'--query','{"operation":"exact","spelling":"farvi"}'])
   json.loads(search.stdout)
 # Verify role/epistemic homes, not only totals: full selected lexical hit comparisons already covered nested values.
 si=exact_expected(baseline,"si'e",raw)['groups'][0]['hits'][0]
 check('all eight context roles',set(x['kind'] for x in si['contexts']),{'Gloss','Note','Label','Register','Domain','Example','Translation','Citation'})
 check('context explicit null',si['contexts'][2]['value'],'Null');check('context present empty',si['contexts'][3]['value']['Value']['text'],'')
 check('etymology explicit null',si['etymologies'][0]['statement'],'Null');check('unknown extension raw lexeme',si['extensions'][0]['value'],'{"nested":[null,false,12345678901234567890]}')
 check('si-e native/mapped roles',[si['entry']['native_word_class'],si['entry']['selmaho'],si['entry']['mapped_pos']['Value']['rule']],[{'Value':'cmavo'},{'Value':'MOI'},'explicit-fixture-map-v1'])
 sn=exact_expected(baseline,'snime',raw)['groups'][0]['hits'][0]
 check('si-e assigned distinct entry',next(f for f in sn['forms'] if f['id']=='form-assigned')['spelling'],"si'e")
 check('computed stem evidence separate',next(f for f in sn['forms'] if f['kind']=='ComputedStem')['evidence'],None)
 check('unqueried opaque preserved',len([a for a in m['assertions'] if a['eligibility']!='Lexical']),1)
 (ROOT/'assembled-reference.json').write_text(json.dumps(reference,indent=2,ensure_ascii=False))
 (ROOT/'results.json').write_text(json.dumps({'status':'PASS','states':results,'commands':len(observations),'checks':len(checks),'check_labels':checks},indent=2,ensure_ascii=False))
 print(json.dumps({'status':'PASS','states':results,'commands':len(observations),'checks':len(checks)},indent=2))
if __name__=='__main__':main()
